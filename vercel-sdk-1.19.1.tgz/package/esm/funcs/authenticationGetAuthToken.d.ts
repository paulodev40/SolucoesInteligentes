import { VercelCore } from "../core.js";
import { RequestOptions } from "../lib/sdks.js";
import { GetAuthTokenRequest, GetAuthTokenResponseBody } from "../models/getauthtokenop.js";
import { ConnectionError, InvalidRequestError, RequestAbortedError, RequestTimeoutError, UnexpectedClientError } from "../models/httpclienterrors.js";
import { ResponseValidationError } from "../models/responsevalidationerror.js";
import { SDKValidationError } from "../models/sdkvalidationerror.js";
import { VercelError } from "../models/vercelerror.js";
import { APIPromise } from "../types/async.js";
import { Result } from "../types/fp.js";
/**
 * Get Auth Token Metadata
 *
 * @remarks
 * Retrieve metadata about an authentication token belonging to the currently authenticated User.
 */
export declare function authenticationGetAuthToken(client: VercelCore, request: GetAuthTokenRequest, options?: RequestOptions): APIPromise<Result<GetAuthTokenResponseBody, VercelError | ResponseValidationError | ConnectionError | RequestAbortedError | RequestTimeoutError | InvalidRequestError | UnexpectedClientError | SDKValidationError>>;
//# sourceMappingURL=authenticationGetAuthToken.d.ts.map