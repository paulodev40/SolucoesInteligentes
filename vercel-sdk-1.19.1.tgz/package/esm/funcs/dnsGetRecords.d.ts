import { VercelCore } from "../core.js";
import { RequestOptions } from "../lib/sdks.js";
import { GetRecordsRequest, GetRecordsResponseBody } from "../models/getrecordsop.js";
import { ConnectionError, InvalidRequestError, RequestAbortedError, RequestTimeoutError, UnexpectedClientError } from "../models/httpclienterrors.js";
import { ResponseValidationError } from "../models/responsevalidationerror.js";
import { SDKValidationError } from "../models/sdkvalidationerror.js";
import { VercelError } from "../models/vercelerror.js";
import { APIPromise } from "../types/async.js";
import { Result } from "../types/fp.js";
/**
 * List existing DNS records
 *
 * @remarks
 * Retrieves a list of DNS records created for a domain name. By default it returns 20 records if no limit is provided. The rest can be retrieved using the pagination options.
 */
export declare function dnsGetRecords(client: VercelCore, request: GetRecordsRequest, options?: RequestOptions): APIPromise<Result<GetRecordsResponseBody, VercelError | ResponseValidationError | ConnectionError | RequestAbortedError | RequestTimeoutError | InvalidRequestError | UnexpectedClientError | SDKValidationError>>;
//# sourceMappingURL=dnsGetRecords.d.ts.map