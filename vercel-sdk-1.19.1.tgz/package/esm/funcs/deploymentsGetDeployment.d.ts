import { VercelCore } from "../core.js";
import { RequestOptions } from "../lib/sdks.js";
import { GetDeploymentRequest, GetDeploymentResponseBody } from "../models/getdeploymentop.js";
import { ConnectionError, InvalidRequestError, RequestAbortedError, RequestTimeoutError, UnexpectedClientError } from "../models/httpclienterrors.js";
import { ResponseValidationError } from "../models/responsevalidationerror.js";
import { SDKValidationError } from "../models/sdkvalidationerror.js";
import { VercelError } from "../models/vercelerror.js";
import { APIPromise } from "../types/async.js";
import { Result } from "../types/fp.js";
/**
 * Get a deployment by ID or URL
 *
 * @remarks
 * Retrieves information for a deployment either by supplying its ID (`id` property) or Hostname (`url` property). Additional details will be included when the authenticated user or team is an owner of the deployment.
 */
export declare function deploymentsGetDeployment(client: VercelCore, request: GetDeploymentRequest, options?: RequestOptions): APIPromise<Result<GetDeploymentResponseBody, VercelError | ResponseValidationError | ConnectionError | RequestAbortedError | RequestTimeoutError | InvalidRequestError | UnexpectedClientError | SDKValidationError>>;
//# sourceMappingURL=deploymentsGetDeployment.d.ts.map