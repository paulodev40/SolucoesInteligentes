import * as z from "zod/v3";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./sdkvalidationerror.js";
export type DeleteRollingReleaseConfigRequest = {
    /**
     * Project ID or project name (URL-encoded)
     */
    idOrName: string;
    /**
     * The Team identifier to perform the request on behalf of.
     */
    teamId?: string | undefined;
    /**
     * The Team slug to perform the request on behalf of.
     */
    slug?: string | undefined;
};
export type DeleteRollingReleaseConfigResponseBody = {
    rollingRelease?: any | null | undefined;
};
/** @internal */
export declare const DeleteRollingReleaseConfigRequest$inboundSchema: z.ZodType<DeleteRollingReleaseConfigRequest, z.ZodTypeDef, unknown>;
/** @internal */
export type DeleteRollingReleaseConfigRequest$Outbound = {
    idOrName: string;
    teamId?: string | undefined;
    slug?: string | undefined;
};
/** @internal */
export declare const DeleteRollingReleaseConfigRequest$outboundSchema: z.ZodType<DeleteRollingReleaseConfigRequest$Outbound, z.ZodTypeDef, DeleteRollingReleaseConfigRequest>;
export declare function deleteRollingReleaseConfigRequestToJSON(deleteRollingReleaseConfigRequest: DeleteRollingReleaseConfigRequest): string;
export declare function deleteRollingReleaseConfigRequestFromJSON(jsonString: string): SafeParseResult<DeleteRollingReleaseConfigRequest, SDKValidationError>;
/** @internal */
export declare const DeleteRollingReleaseConfigResponseBody$inboundSchema: z.ZodType<DeleteRollingReleaseConfigResponseBody, z.ZodTypeDef, unknown>;
/** @internal */
export type DeleteRollingReleaseConfigResponseBody$Outbound = {
    rollingRelease?: any | null | undefined;
};
/** @internal */
export declare const DeleteRollingReleaseConfigResponseBody$outboundSchema: z.ZodType<DeleteRollingReleaseConfigResponseBody$Outbound, z.ZodTypeDef, DeleteRollingReleaseConfigResponseBody>;
export declare function deleteRollingReleaseConfigResponseBodyToJSON(deleteRollingReleaseConfigResponseBody: DeleteRollingReleaseConfigResponseBody): string;
export declare function deleteRollingReleaseConfigResponseBodyFromJSON(jsonString: string): SafeParseResult<DeleteRollingReleaseConfigResponseBody, SDKValidationError>;
//# sourceMappingURL=deleterollingreleaseconfigop.d.ts.map