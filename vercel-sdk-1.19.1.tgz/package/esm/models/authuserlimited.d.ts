import * as z from "zod/v3";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./sdkvalidationerror.js";
/**
 * A limited form of data for the currently authenticated User, due to the authentication token missing privileges to read the full User data.
 */
export type AuthUserLimited = {
    /**
     * Property indicating that this User data contains only limited information, due to the authentication token missing privileges to read the full User data. Re-login with email, GitHub, GitLab or Bitbucket in order to upgrade the authentication token with the necessary privileges.
     */
    limited: boolean;
    /**
     * The User's unique identifier.
     */
    id: string;
    /**
     * Email address associated with the User account.
     */
    email: string;
    /**
     * Name associated with the User account, or `null` if none has been provided.
     */
    name: string | null;
    /**
     * Unique username associated with the User account.
     */
    username: string;
    /**
     * SHA1 hash of the avatar for the User account. Can be used in conjuction with the ... endpoint to retrieve the avatar image.
     */
    avatar: string | null;
    /**
     * The user's default team.
     */
    defaultTeamId: string | null;
};
/** @internal */
export declare const AuthUserLimited$inboundSchema: z.ZodType<AuthUserLimited, z.ZodTypeDef, unknown>;
/** @internal */
export type AuthUserLimited$Outbound = {
    limited: boolean;
    id: string;
    email: string;
    name: string | null;
    username: string;
    avatar: string | null;
    defaultTeamId: string | null;
};
/** @internal */
export declare const AuthUserLimited$outboundSchema: z.ZodType<AuthUserLimited$Outbound, z.ZodTypeDef, AuthUserLimited>;
export declare function authUserLimitedToJSON(authUserLimited: AuthUserLimited): string;
export declare function authUserLimitedFromJSON(jsonString: string): SafeParseResult<AuthUserLimited, SDKValidationError>;
//# sourceMappingURL=authuserlimited.d.ts.map