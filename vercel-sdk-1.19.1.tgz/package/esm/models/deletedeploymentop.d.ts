import * as z from "zod/v3";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./sdkvalidationerror.js";
export type DeleteDeploymentRequest = {
    /**
     * The ID of the deployment to be deleted
     */
    id: string;
    /**
     * A Deployment or Alias URL. In case it is passed, the ID will be ignored
     */
    url?: string | undefined;
    /**
     * The Team identifier to perform the request on behalf of.
     */
    teamId?: string | undefined;
    /**
     * The Team slug to perform the request on behalf of.
     */
    slug?: string | undefined;
};
/**
 * A constant with the final state of the deployment.
 */
export declare const DeleteDeploymentState: {
    readonly Deleted: "DELETED";
};
/**
 * A constant with the final state of the deployment.
 */
export type DeleteDeploymentState = ClosedEnum<typeof DeleteDeploymentState>;
/**
 * The deployment was successfully deleted
 */
export type DeleteDeploymentResponseBody = {
    /**
     * The removed deployment ID.
     */
    uid: string;
    /**
     * A constant with the final state of the deployment.
     */
    state: DeleteDeploymentState;
};
/** @internal */
export declare const DeleteDeploymentRequest$inboundSchema: z.ZodType<DeleteDeploymentRequest, z.ZodTypeDef, unknown>;
/** @internal */
export type DeleteDeploymentRequest$Outbound = {
    id: string;
    url?: string | undefined;
    teamId?: string | undefined;
    slug?: string | undefined;
};
/** @internal */
export declare const DeleteDeploymentRequest$outboundSchema: z.ZodType<DeleteDeploymentRequest$Outbound, z.ZodTypeDef, DeleteDeploymentRequest>;
export declare function deleteDeploymentRequestToJSON(deleteDeploymentRequest: DeleteDeploymentRequest): string;
export declare function deleteDeploymentRequestFromJSON(jsonString: string): SafeParseResult<DeleteDeploymentRequest, SDKValidationError>;
/** @internal */
export declare const DeleteDeploymentState$inboundSchema: z.ZodNativeEnum<typeof DeleteDeploymentState>;
/** @internal */
export declare const DeleteDeploymentState$outboundSchema: z.ZodNativeEnum<typeof DeleteDeploymentState>;
/** @internal */
export declare const DeleteDeploymentResponseBody$inboundSchema: z.ZodType<DeleteDeploymentResponseBody, z.ZodTypeDef, unknown>;
/** @internal */
export type DeleteDeploymentResponseBody$Outbound = {
    uid: string;
    state: string;
};
/** @internal */
export declare const DeleteDeploymentResponseBody$outboundSchema: z.ZodType<DeleteDeploymentResponseBody$Outbound, z.ZodTypeDef, DeleteDeploymentResponseBody>;
export declare function deleteDeploymentResponseBodyToJSON(deleteDeploymentResponseBody: DeleteDeploymentResponseBody): string;
export declare function deleteDeploymentResponseBodyFromJSON(jsonString: string): SafeParseResult<DeleteDeploymentResponseBody, SDKValidationError>;
//# sourceMappingURL=deletedeploymentop.d.ts.map