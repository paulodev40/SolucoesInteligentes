import * as z from "zod/v3";
import { ClosedEnum } from "../types/enums.js";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./sdkvalidationerror.js";
/**
 * The project role that will be added to this Access Group. \"null\" will remove this project level role.
 */
export declare const CreateAccessGroupRole: {
    readonly Admin: "ADMIN";
    readonly ProjectViewer: "PROJECT_VIEWER";
    readonly ProjectDeveloper: "PROJECT_DEVELOPER";
};
/**
 * The project role that will be added to this Access Group. \"null\" will remove this project level role.
 */
export type CreateAccessGroupRole = ClosedEnum<typeof CreateAccessGroupRole>;
export type CreateAccessGroupProjects = {
    /**
     * The ID of the project.
     */
    projectId: string;
    /**
     * The project role that will be added to this Access Group. \"null\" will remove this project level role.
     */
    role: CreateAccessGroupRole | null;
};
export type CreateAccessGroupRequestBody = {
    /**
     * The name of the access group
     */
    name: string;
    projects?: Array<CreateAccessGroupProjects> | undefined;
    /**
     * List of members to add to the access group.
     */
    membersToAdd?: Array<string> | undefined;
};
export type CreateAccessGroupRequest = {
    /**
     * The Team identifier to perform the request on behalf of.
     */
    teamId?: string | undefined;
    /**
     * The Team slug to perform the request on behalf of.
     */
    slug?: string | undefined;
    requestBody: CreateAccessGroupRequestBody;
};
export declare const CreateAccessGroupEntitlements: {
    readonly V0: "v0";
};
export type CreateAccessGroupEntitlements = ClosedEnum<typeof CreateAccessGroupEntitlements>;
export type CreateAccessGroupResponseBody = {
    entitlements: Array<CreateAccessGroupEntitlements>;
    membersCount: number;
    projectsCount: number;
    /**
     * The name of this access group.
     */
    name: string;
    /**
     * Timestamp in milliseconds when the access group was created.
     */
    createdAt: string;
    /**
     * ID of the team that this access group belongs to.
     */
    teamId: string;
    /**
     * Timestamp in milliseconds when the access group was last updated.
     */
    updatedAt: string;
    /**
     * ID of the access group.
     */
    accessGroupId: string;
    /**
     * Roles that the team has in the access group.
     */
    teamRoles?: Array<string> | undefined;
    /**
     * Permissions that the team has in the access group.
     */
    teamPermissions?: Array<string> | undefined;
};
/** @internal */
export declare const CreateAccessGroupRole$inboundSchema: z.ZodNativeEnum<typeof CreateAccessGroupRole>;
/** @internal */
export declare const CreateAccessGroupRole$outboundSchema: z.ZodNativeEnum<typeof CreateAccessGroupRole>;
/** @internal */
export declare const CreateAccessGroupProjects$inboundSchema: z.ZodType<CreateAccessGroupProjects, z.ZodTypeDef, unknown>;
/** @internal */
export type CreateAccessGroupProjects$Outbound = {
    projectId: string;
    role: string | null;
};
/** @internal */
export declare const CreateAccessGroupProjects$outboundSchema: z.ZodType<CreateAccessGroupProjects$Outbound, z.ZodTypeDef, CreateAccessGroupProjects>;
export declare function createAccessGroupProjectsToJSON(createAccessGroupProjects: CreateAccessGroupProjects): string;
export declare function createAccessGroupProjectsFromJSON(jsonString: string): SafeParseResult<CreateAccessGroupProjects, SDKValidationError>;
/** @internal */
export declare const CreateAccessGroupRequestBody$inboundSchema: z.ZodType<CreateAccessGroupRequestBody, z.ZodTypeDef, unknown>;
/** @internal */
export type CreateAccessGroupRequestBody$Outbound = {
    name: string;
    projects?: Array<CreateAccessGroupProjects$Outbound> | undefined;
    membersToAdd?: Array<string> | undefined;
};
/** @internal */
export declare const CreateAccessGroupRequestBody$outboundSchema: z.ZodType<CreateAccessGroupRequestBody$Outbound, z.ZodTypeDef, CreateAccessGroupRequestBody>;
export declare function createAccessGroupRequestBodyToJSON(createAccessGroupRequestBody: CreateAccessGroupRequestBody): string;
export declare function createAccessGroupRequestBodyFromJSON(jsonString: string): SafeParseResult<CreateAccessGroupRequestBody, SDKValidationError>;
/** @internal */
export declare const CreateAccessGroupRequest$inboundSchema: z.ZodType<CreateAccessGroupRequest, z.ZodTypeDef, unknown>;
/** @internal */
export type CreateAccessGroupRequest$Outbound = {
    teamId?: string | undefined;
    slug?: string | undefined;
    RequestBody: CreateAccessGroupRequestBody$Outbound;
};
/** @internal */
export declare const CreateAccessGroupRequest$outboundSchema: z.ZodType<CreateAccessGroupRequest$Outbound, z.ZodTypeDef, CreateAccessGroupRequest>;
export declare function createAccessGroupRequestToJSON(createAccessGroupRequest: CreateAccessGroupRequest): string;
export declare function createAccessGroupRequestFromJSON(jsonString: string): SafeParseResult<CreateAccessGroupRequest, SDKValidationError>;
/** @internal */
export declare const CreateAccessGroupEntitlements$inboundSchema: z.ZodNativeEnum<typeof CreateAccessGroupEntitlements>;
/** @internal */
export declare const CreateAccessGroupEntitlements$outboundSchema: z.ZodNativeEnum<typeof CreateAccessGroupEntitlements>;
/** @internal */
export declare const CreateAccessGroupResponseBody$inboundSchema: z.ZodType<CreateAccessGroupResponseBody, z.ZodTypeDef, unknown>;
/** @internal */
export type CreateAccessGroupResponseBody$Outbound = {
    entitlements: Array<string>;
    membersCount: number;
    projectsCount: number;
    name: string;
    createdAt: string;
    teamId: string;
    updatedAt: string;
    accessGroupId: string;
    teamRoles?: Array<string> | undefined;
    teamPermissions?: Array<string> | undefined;
};
/** @internal */
export declare const CreateAccessGroupResponseBody$outboundSchema: z.ZodType<CreateAccessGroupResponseBody$Outbound, z.ZodTypeDef, CreateAccessGroupResponseBody>;
export declare function createAccessGroupResponseBodyToJSON(createAccessGroupResponseBody: CreateAccessGroupResponseBody): string;
export declare function createAccessGroupResponseBodyFromJSON(jsonString: string): SafeParseResult<CreateAccessGroupResponseBody, SDKValidationError>;
//# sourceMappingURL=createaccessgroupop.d.ts.map