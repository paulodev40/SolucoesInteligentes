import * as z from "zod/v3";
import { Result as SafeParseResult } from "../types/fp.js";
import { SDKValidationError } from "./sdkvalidationerror.js";
export type AssignAliasRequestBody = {
    /**
     * The alias we want to assign to the deployment defined in the URL
     */
    alias?: string | undefined;
    /**
     * The redirect property will take precedence over the deployment id from the URL and consists of a hostname (like test.com) to which the alias should redirect using status code 307
     */
    redirect?: string | null | undefined;
};
export type AssignAliasRequest = {
    /**
     * The ID of the deployment the aliases should be listed for
     */
    id: string;
    /**
     * The Team identifier to perform the request on behalf of.
     */
    teamId?: string | undefined;
    /**
     * The Team slug to perform the request on behalf of.
     */
    slug?: string | undefined;
    requestBody: AssignAliasRequestBody;
};
/**
 * The alias was successfully assigned to the deployment
 */
export type AssignAliasResponseBody = {
    /**
     * The unique identifier of the alias
     */
    uid: string;
    /**
     * The assigned alias name
     */
    alias: string;
    /**
     * The date when the alias was created
     */
    created: Date;
    /**
     * The unique identifier of the previously aliased deployment, only received when the alias was used before
     */
    oldDeploymentId?: string | null | undefined;
};
/** @internal */
export declare const AssignAliasRequestBody$inboundSchema: z.ZodType<AssignAliasRequestBody, z.ZodTypeDef, unknown>;
/** @internal */
export type AssignAliasRequestBody$Outbound = {
    alias?: string | undefined;
    redirect?: string | null | undefined;
};
/** @internal */
export declare const AssignAliasRequestBody$outboundSchema: z.ZodType<AssignAliasRequestBody$Outbound, z.ZodTypeDef, AssignAliasRequestBody>;
export declare function assignAliasRequestBodyToJSON(assignAliasRequestBody: AssignAliasRequestBody): string;
export declare function assignAliasRequestBodyFromJSON(jsonString: string): SafeParseResult<AssignAliasRequestBody, SDKValidationError>;
/** @internal */
export declare const AssignAliasRequest$inboundSchema: z.ZodType<AssignAliasRequest, z.ZodTypeDef, unknown>;
/** @internal */
export type AssignAliasRequest$Outbound = {
    id: string;
    teamId?: string | undefined;
    slug?: string | undefined;
    RequestBody: AssignAliasRequestBody$Outbound;
};
/** @internal */
export declare const AssignAliasRequest$outboundSchema: z.ZodType<AssignAliasRequest$Outbound, z.ZodTypeDef, AssignAliasRequest>;
export declare function assignAliasRequestToJSON(assignAliasRequest: AssignAliasRequest): string;
export declare function assignAliasRequestFromJSON(jsonString: string): SafeParseResult<AssignAliasRequest, SDKValidationError>;
/** @internal */
export declare const AssignAliasResponseBody$inboundSchema: z.ZodType<AssignAliasResponseBody, z.ZodTypeDef, unknown>;
/** @internal */
export type AssignAliasResponseBody$Outbound = {
    uid: string;
    alias: string;
    created: string;
    oldDeploymentId?: string | null | undefined;
};
/** @internal */
export declare const AssignAliasResponseBody$outboundSchema: z.ZodType<AssignAliasResponseBody$Outbound, z.ZodTypeDef, AssignAliasResponseBody>;
export declare function assignAliasResponseBodyToJSON(assignAliasResponseBody: AssignAliasResponseBody): string;
export declare function assignAliasResponseBodyFromJSON(jsonString: string): SafeParseResult<AssignAliasResponseBody, SDKValidationError>;
//# sourceMappingURL=assignaliasop.d.ts.map